export default function Insights() {
  return <h1>Insights</h1>;
}
